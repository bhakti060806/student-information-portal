# Student Information Portal — ExpressJS

A student record portal built for Web Technology Practical No. 5. It demonstrates Express routing, route parameters, built-in and custom middleware, server-side validation with `express-validator`, EJS views, static CSS, and central error handling.

## Requirements
- Node.js 18 or newer
- npm (included with Node.js)

## Run locally
1. Extract the ZIP.
2. Open a terminal in this project folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the application:
   ```bash
   npm start
   ```
5. Open `http://localhost:3000`.

For development with automatic restarts, run `npm install` and then `npm run dev`.

## Main routes
| Method | Route | Purpose |
|---|---|---|
| GET | `/` | Dashboard |
| GET | `/students` | List students |
| GET | `/students/new` | Registration form |
| POST | `/students` | Validate and create a student |
| GET | `/students/:id` | View a student by route parameter |
| Any unmatched route | — | 404 error page |

## Validation
The server validates name length, PRN format and uniqueness, email format and uniqueness, department, and academic year. Invalid submissions return HTTP 400 and redisplay the form with messages. Missing student IDs return a 404 page.

## Deployment
Deploy to a Node.js hosting provider such as Render:
1. Push this project to a GitHub repository (do not commit `node_modules`).
2. Create a new Web Service on Render and connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Deploy and test the generated public URL.

The host supplies the `PORT` environment variable; the application uses `process.env.PORT`.

## Limitations
Student data is stored in a JavaScript array and resets when the process restarts. This is a demonstration project, not a production database. Add persistent database storage and authentication before real-world use.

## Files to submit
Submit the source ZIP without `node_modules` or secrets. Include your deployed URL and GitHub URL in the online text field on Moodle, and submit a PDF report with screenshots and the AI-use declaration requested by the assignment.
